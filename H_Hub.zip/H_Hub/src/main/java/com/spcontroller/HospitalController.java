package com.spcontroller;

import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.duo.Hospital_Duo;
import com.model.Appoiment;
import com.model.Appoiment_Manager;
import com.model.Doctor;
import com.model.Hospital;
import com.model.User;
import com.mysql.cj.Session;

@Controller
public class HospitalController {
	
	@RequestMapping("/add_dr")
	public String add_dr() 
	{
		 return "Add_dr";  
	}
	@RequestMapping("/dr")
	public ModelAndView dr(HttpServletRequest req,HttpSession session) {
		String dr_name=req.getParameter("dName");    
		String specialization=req.getParameter("dSpe");
		ModelAndView mv=new ModelAndView();
		mv.setViewName("Add_dr");
		mv.addObject("sucess","Your Record Insert Sucess Fully");
		Hospital_Duo h=new Hospital_Duo();
		try {
			int id=Integer.parseInt(session.getAttribute("id").toString());
			
			Hospital hospital=new Hospital();
			hospital.setId(h.find_h_id(id));
			Doctor d=new Doctor();
			d.setH(hospital);
			d.setName(dr_name);
			d.setSpecialization(specialization);
			h.add_dr(d);
			
		}
		catch (Exception e) {
			System.out.println(e);
		}
		
		return mv; 
		
	}

	@RequestMapping("/disp_data")
	public  ModelAndView dis_data(HttpServletRequest req,HttpSession session) {
		List<Doctor> doctors=(List<Doctor>) req.getAttribute("doctors");
		for(Doctor doctor : doctors) {
            System.out.println(doctor.getName());
        }
		ModelAndView mv=new ModelAndView();
		mv.setViewName("dIs_data");
		mv.addObject("doctors",doctors);
		return mv;
	}
	
	@RequestMapping("/del_dr")
	public String del_dr(HttpServletRequest request,HttpSession session)  {
		try {
			Doctor dr=new Doctor();
			Hospital_Duo d=new Hospital_Duo();
			int id=Integer.parseInt(request.getParameter("id"));
			dr.setId(id);
			d.del_dr(dr);		
			 id=Integer.parseInt(session.getAttribute("id").toString());
			int i=d.find_h_id(id);
			dr.setId(id);
			d.del_dr(dr);
			
			String link="forward:/show_doctor?id="+String.valueOf(i);
			System.out.print(link);
			return link;		

		}
		catch (Exception e) {
			System.out.println(e);
			return "";	
		}
	}
	@RequestMapping(value = "/up_dr")
	public ModelAndView up_dr(HttpServletRequest request) {
		Doctor dr=new Doctor();
		Hospital_Duo d=new Hospital_Duo();		
		int id=Integer.parseInt(request.getParameter("id"));		
		 dr=d.fetch_record_fr(id);
		
		ModelAndView mv=new ModelAndView();
		mv.addObject("doctors",dr);
		mv.setViewName("Upp_dr");
		return mv;
	}
	@RequestMapping(value = "/udr",method = RequestMethod.GET)
	public String udr(HttpServletRequest req,HttpSession session) {
		int uid=Integer.parseInt(req.getParameter("dNo"));
		String dr_name=req.getParameter("dName");    
		String specialization=req.getParameter("dSpe");
		Doctor d=new Doctor();
		d.setName(dr_name);
		d.setSpecialization(specialization);
		d.setId(uid);
		
		int id=Integer.parseInt(session.getAttribute("id").toString());		
		System.out.println(id);
		Hospital hospital=new Hospital();
		Hospital_Duo h=new Hospital_Duo();	
		int i=h.find_h_id(id);
		hospital.setId(i);
		d.setH(hospital);
		boolean check=h.update_dr(d);
		
		String link="forward:/show_doctor?id="+String.valueOf(i);
		System.out.print(d.getId()+d.getName()+d.getSpecialization()+check);
		System.out.print(link);
		return link;
		
	}
	@RequestMapping("/showDr")
	public String showDr(HttpSession session) {
		try {
			int id=Integer.parseInt(session.getAttribute("id").toString());		
			System.out.println(id);
			Hospital hospital=new Hospital();
			Hospital_Duo h=new Hospital_Duo();
			int i=h.find_h_id(id);
			String link="forward:/show_doctor?id="+String.valueOf(i);
			System.out.print(link);
			return link;
		}
		catch (Exception e) {
			return "Login";
		}
		
	}
	@RequestMapping("/showDrAp")
	public String showDrAp(HttpSession session) {
		try {
			int id=Integer.parseInt(session.getAttribute("id").toString());		
			System.out.println(id);
			Hospital hospital=new Hospital();
			Hospital_Duo h=new Hospital_Duo();
			int i=h.find_h_id(id);
			String link="forward:/Show_Doctor_Appoiment?id="+String.valueOf(i);
			System.out.print(link);
			return link;
		}
		catch (Exception e) {
			return "Login";
		}
		
	}
	@RequestMapping("/add_ap")
	public ModelAndView add_ap(HttpSession session,HttpServletRequest request) {
		ModelAndView mv=new ModelAndView();
		try {
			int id=Integer.parseInt(request.getParameter("id"));		
			/*
			 * out.println("<script type=\"text/javascript\">");
			 * out.println("alert('User or password incorrect');");
			 * out.println("window.location = 'http://localhost:8080/H_Hub/';\r\n" + "");
			 * out.println("</script>");
			 */
			
			
			mv.setViewName("addApoiment");
			mv.addObject("id",id);						
			return mv;
		      					
		}
		catch (Exception e) {
			System.out.print(e);
			return mv;
		}
		
	}
	@RequestMapping("AddAp")
	public ModelAndView AddAp(HttpServletRequest request) {
		int id=Integer.parseInt(request.getParameter("d_id"));
		String date=request.getParameter("d_date");
		String time=request.getParameter("d_time");
		Appoiment ap=new Appoiment();
		Doctor d=new Doctor();
		d.setId(id);
		ap.setD(d);
		ap.setDt(date);
		ap.setTime(time);		
		Hospital_Duo hd=new Hospital_Duo();
		hd.add_appoiment(ap);		
		ModelAndView mv=new ModelAndView();
		mv.setViewName("addApoiment");
		mv.addObject("id",id);		
		mv.addObject("message","Add Appoiment Sucess Fully");		
		return mv;
		
	}
	@RequestMapping("UpApp")
	public void UpApp(HttpServletRequest request,PrintWriter out) {
		try {
			int id=Integer.parseInt(request.getParameter("id"));
			int d_id=Integer.parseInt(request.getParameter("d_id"));			
			String time=request.getParameter("d_time");
			String date=request.getParameter("d_date");
		
			Doctor d=new Doctor();
			d.setId(d_id);
			Appoiment ap=new Appoiment();
			ap.setD(d);
			ap.setDt(date);
			ap.setId(id);
			ap.setTime(time);
			Hospital_Duo hd=new Hospital_Duo();
			hd.update_appoiment(ap);			
			System.out.println(time);
			
			  out.println("<script type=\"text/javascript\">");
			  out.println("alert('Your Data is Updated');");
			  out.println("window.location = 'http://localhost:8080/H_Hub/showDrAp';\r\n" + "");
			  out.println("</script>");
			 
			
					
		} catch (Exception e) {
			
			// TODO: handle exception
		}
	}
	@RequestMapping("del_ap")
	public void del_ap(HttpServletRequest request,PrintWriter out) {
		int id=Integer.parseInt(request.getParameter("id"));
		Appoiment ap=new Appoiment();
		ap.setId(id);
		Hospital_Duo hd=new Hospital_Duo();
		hd.del_appoiment(ap);
		out.println("<script type=\"text/javascript\">");
		out.println("alert('Your Data is Deleted Sucessfully');");
		out.println("window.location = 'http://localhost:8080/H_Hub/showDrAp';\r\n" + "");
		out.println("</script>");
		 
	}
	
	@RequestMapping("up_hos")
	public ModelAndView up_hos(HttpServletRequest request,PrintWriter out,HttpSession session) {
		int id=Integer.parseInt(session.getAttribute("id").toString());
		Hospital_Duo hd=new Hospital_Duo();
		int h_id=hd.find_h_id(id);		
		System.out.print(h_id);
		Hospital h=hd.show_rec(h_id);
		System.out.println(h.getAddress());
		ModelAndView mv=new ModelAndView();
		mv.addObject("Hospital",h);
		mv.setViewName("update_hos");
		return mv;
		 
	}
	@RequestMapping(value = "up_ho",method = RequestMethod.POST)
	public void up_po(HttpServletRequest request,PrintWriter out,HttpSession session){
		try {
		String h_name=request.getParameter("h_name");
		String h_tel=request.getParameter("h_tel");
		String h_add=request.getParameter("h_add");
		int id=Integer.parseInt(request.getParameter("id"));
		System.out.println(h_name+h_add+h_tel);
		Hospital hospital=new Hospital();
		hospital.setAddress(h_add);
		hospital.setId(id);
		hospital.setName(h_name);
		hospital.setTelephone(h_tel);
		Hospital_Duo hd=new Hospital_Duo();
		hd.up_ho(hospital);
		out.println("<script type=\"text/javascript\">");
		out.println("alert('Your Data is Update Sucessfully');");
		out.println("window.location = 'http://localhost:8080/H_Hub/Login';\r\n" + "");
		out.println("</script>");
		}
		catch (Exception e) {
			
		}
	}
	@RequestMapping("/AppoimentManaer")
	public String Am(HttpSession session) {
		try {
			int id=Integer.parseInt(session.getAttribute("id").toString());		
			System.out.println(id);
			Hospital hospital=new Hospital();
			Hospital_Duo h=new Hospital_Duo();
			int i=h.find_h_id(id);
			String link="forward:/Check_Dr_Appoiment_Status?id="+String.valueOf(i);
			System.out.print(link);
			return link;
		}
		catch (Exception e) {
			return "Login";
		}
	}
	@RequestMapping("/ap_con")
	public void  ap_con(HttpServletRequest request,PrintWriter out) {
		try {
			String id=request.getParameter("id");	
			String a_id=request.getParameter("a_id");
			Appoiment_Manager am=new Appoiment_Manager();
			am.setId(Integer.parseInt(id));
			am.setStatus("Conform");
			Hospital_Duo hd=new Hospital_Duo();
			hd.appoimentbook_update(am);
			out.println("<script type=\"text/javascript\">");
			out.println("alert('Appoiment is Conform Sucessfully');");
			out.println("window.location = 'http://localhost:8080/H_Hub/ap_pen?id=" + a_id +"'");
			out.println("</script>");
		}
		catch (Exception e) {
			
		}
	}
	@RequestMapping("/ap_rej")
	public void ap_rej(HttpServletRequest request,PrintWriter out) {
		try {
			String id=request.getParameter("id");	
			String a_id=request.getParameter("a_id");
			Appoiment_Manager am=new Appoiment_Manager();
			am.setId(Integer.parseInt(id));
			am.setStatus("Reject");
			Hospital_Duo hd=new Hospital_Duo();
			hd.appoimentbook_update(am);
			out.println("<script type=\"text/javascript\">");
			out.println("alert('Appoiment is Reject Sucessfully');");
			out.println("window.location = 'http://localhost:8080/H_Hub/ap_pen?id=" + a_id +"'");
			out.println("</script>");
		}
		catch (Exception e) {
			
		}
	}
	@RequestMapping("/ap_com")
	public void ap_com(HttpServletRequest request,PrintWriter out) {
		try {
			String id=request.getParameter("id");	
			String a_id=request.getParameter("a_id");
			Appoiment_Manager am=new Appoiment_Manager();
			am.setId(Integer.parseInt(id));
			am.setStatus("Complete");
			Hospital_Duo hd=new Hospital_Duo();
			hd.appoimentbook_update(am);
			out.println("<script type=\"text/javascript\">");
			out.println("alert('Appoiment is Complete Sucessfully');");
			out.println("window.location = 'http://localhost:8080/H_Hub/ap_ac?id=" + a_id +"'");
			out.println("</script>");
		}
		catch (Exception e) {
			
		}
	}
	@RequestMapping("/ap_rate")
	public void ap_rate(HttpServletRequest request,PrintWriter out) {
		try {
			String rate=request.getParameter("rate");	
			String a_id=request.getParameter("am_id");
			Appoiment_Manager am=new Appoiment_Manager();
			am.setId(Integer.parseInt(a_id));
			am.setStatus("Complete");
			am.setRate(Integer.parseInt(rate));
			Hospital_Duo hd=new Hospital_Duo();
			hd.appoimentbook_update(am);
			out.println("<script type=\"text/javascript\">");
			out.println("alert('Appoiment is rated Sucessfully');");
			out.println("window.location = 'http://localhost:8080/H_Hub/Rate_Appoiment'");
			out.println("</script>");
		}
		catch (Exception e) {
			System.out.print(e);
		}
	}
}
