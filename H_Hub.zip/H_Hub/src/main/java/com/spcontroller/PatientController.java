package com.spcontroller;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.duo.Hospital_Duo;
import com.model.Appoiment;
import com.model.Appoiment_Manager;
import com.model.Card;
import com.model.User;

@Controller
public class PatientController {
	@RequestMapping("/BookAp")
	public void BookAp(HttpServletRequest request,HttpSession session,PrintWriter out) {
		try {
			int a_id=Integer.parseInt(request.getParameter("a_id"));					
			String time=request.getParameter("d_time");
			String date=request.getParameter("d_date");
			String name=request.getParameter("p_name");
			String p_num=request.getParameter("p_num");
			String cc_number=request.getParameter("cr_no");
			String cc_exp=request.getParameter("cr_exp");
			String cc_cvc=request.getParameter("cr_Cvv");
			String cr_Name=request.getParameter("cr_Name");
			Appoiment_Manager am=new Appoiment_Manager();
			Appoiment ap=new Appoiment();
			ap.setId(a_id);
			User u=new User();
			u.setId(Integer.parseInt(session.getAttribute("id").toString()));
			am.setA(ap);
			am.setCn(p_num);
			am.setName(name);
			am.setPs("Sucess Full");
			am.setStatus("Panding");
			am.setU(u);
			Card c=new Card();
			c.setAm(am);
			c.setName(cr_Name);
			c.setCr_no(cc_number);
			c.setCvv(cc_cvc);
			c.setName(cr_Name);
			c.setExp(cc_exp);
			Hospital_Duo hc=new Hospital_Duo();
			hc.book_appoiment(am, c);
			
			  out.println("<script type=\"text/javascript\">");
			  out.println("alert('Your Appoment  is Book Sucessfully');");
			  out.println("window.location = 'http://localhost:8080/H_Hub/Login';\r\n" +
			  ""); out.println("</script>");
			 
			
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
	}
}
