package com.spcontroller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.duo.Hospital_Duo;
import com.duo.User_Duo;
import com.email.EmailClient;
import com.model.Hospital;
import com.model.Staff;
import com.model.User;
import com.mysql.cj.Session;

@Controller  
public class UserController {  
	@RequestMapping("/")
    public String display()  
    {  
				
        return "index";  
    }    
	@RequestMapping("/Contact_Us")
	public String contact_us() 
	{
		return "Contact_Us";
	}
	@RequestMapping("/SubmitForm")
	public void SubmitForm(HttpServletRequest req,PrintWriter out) throws MessagingException {
		String FirstName=req.getParameter("firstname");
		String LastName=req.getParameter("lastname");
		String Email=req.getParameter("Email");
		String subject=req.getParameter("subject");
		String message="One New Contact Us Message From <br><table border='1'><tr><th>"+"FirstName"+"</th><th>"+"LastName"+"</th><th>"+"subject"+"</th></tr><tr><td>"+FirstName+"</td><td>"+LastName+"</td><td>"+subject+"</td></tr></table>";
		EmailClient.sendAsHtml("noreplay.hospital.hub@gmail.com", "ContactUs", message);
		out.println("<script type=\"text/javascript\">");
		  out.println("alert('Thanks For Submitting,We are Contact You Soon');");
		  out.println("window.location = 'http://localhost:8080/H_Hub/Login';\r\n" + "");
		  out.println("</script>");
	}
	@RequestMapping("/Register")  
    public String reg()  
    {  
				
        return "Register";  
    }
	
	@RequestMapping(value="/add_User", method = RequestMethod.POST)  
    public ModelAndView add_user(HttpServletRequest req,Model m) throws MessagingException  
    {  
		String name=req.getParameter("u_name");    
		String email=req.getParameter("u_emial");
		String c_pin=req.getParameter("u_pin");
		String c_ph=req.getParameter("u_no");
		String c_Phone=c_pin+" "+c_ph;
		String pass=req.getParameter("u_pass");		
		User_Duo ud=new User_Duo();
		User u=new User();
		u.setEmail(email);
		u.setContact_Number(c_Phone);		
		u.setName(name);
		u.setPassword(pass);
		u.setOtp(ud.otp_genrate());
		u.setUtype("Patient");
		System.out.println(u.getOtp());
		String mess="<h2>"+u.getOtp()+"</h2><p>This is Your One Time Password</p>";		
		EmailClient.sendAsHtml(u.getEmail(),"Registration OTP",mess);
		ModelAndView mv=new ModelAndView();
		mv.setViewName("OTP");
		mv.addObject("user",u);
        return mv;  
    }
	@RequestMapping(value="/add_Hos", method = RequestMethod.POST)  
    public ModelAndView add_hos(HttpServletRequest req,Model m) throws MessagingException  
    {  
		String h_name=req.getParameter("h_name");
		String h_tel=req.getParameter("h_tel");
		String h_add=req.getParameter("h_add");
		String name=req.getParameter("u_name");    
		String email=req.getParameter("u_emial");
		String c_pin=req.getParameter("u_pin");
		String c_ph=req.getParameter("u_no");
		String c_Phone=c_pin+" "+c_ph;
		String pass=req.getParameter("u_pass");		
		User_Duo ud=new User_Duo();
		User u=new User();
		u.setEmail(email);
		u.setContact_Number(c_Phone);		
		u.setName(name);
		u.setPassword(pass);
		u.setOtp(ud.otp_genrate());
		u.setUtype("Staff");
		Hospital h=new Hospital();
		h.setAddress(h_add);
		h.setName(name);
		h.setTelephone(h_tel);
		Staff staff=new Staff();
		staff.setHospital(h);
		staff.setUser(u);
		System.out.println(u.getOtp());
		String mess="<h2>"+u.getOtp()+"</h2><p>This is Your One Time Password</p>";		
		EmailClient.sendAsHtml(u.getEmail(),"Registration OTP",mess);
		ModelAndView mv=new ModelAndView();
		mv.setViewName("HOS_OTP");
		mv.addObject("user",u);
		mv.addObject("hos",h);
        return mv;  
    }
	@RequestMapping(value="/add_Hos_otp", method = RequestMethod.POST)  
    public ModelAndView add_Hos_otp(HttpServletRequest req,Model m) throws MessagingException  
    {  
		String h_name=req.getParameter("h_name");
		String h_tel=req.getParameter("h_tel");
		String h_add=req.getParameter("h_add");
		String name=req.getParameter("u_name");    
		String email=req.getParameter("u_emial");
		
		String c_ph=req.getParameter("u_no");
		String c_Phone=c_ph;
		String pass=req.getParameter("u_pass");
		String u_otp_user=req.getParameter("u_otp_user");
		String u_otp_def=req.getParameter("u_otp_def");
		User_Duo ud=new User_Duo();
		User u=new User();
		u.setEmail(email);
		u.setContact_Number(c_Phone);		
		u.setName(name);
		u.setPassword(pass);		
		u.setUtype("Staff");
		Hospital h=new Hospital();		
		h.setName(name);
		h.setAddress(h_add);
		h.setTelephone(h_tel);		
		Staff staff=new Staff();
		staff.setHospital(h);
		staff.setUser(u);
		
		ModelAndView mv=new ModelAndView();
		if(u_otp_def.equals(u_otp_user)) {							
			User_Duo udDuo=new User_Duo();
			boolean status=udDuo.User_Register_Staff(u,h);
			if(status==true) {
				mv.setViewName("Login");				
				return mv;
			}
			if(status==false) {
				mv.setViewName("HospitalRegister");
				mv.addObject("Error","Your Email is Already Register");
				return mv;
			}
	          
		}
		else {
			
			System.out.print("Address"+h.getAddress());
			mv.setViewName("HOS_OTP");
			mv.addObject("user",u);
			mv.addObject("hos",h);	
			
	        return mv;  
		}
		return mv;  
    }
	@RequestMapping(value = "/otp_sub",method = RequestMethod.POST)
	public ModelAndView otp_sub(HttpServletRequest req,Model m) {
		String name=req.getParameter("u_name");    
		String email=req.getParameter("u_emial");		
		String c_pass=req.getParameter("u_pass");
		String c_Phone=req.getParameter("u_no");
		String u_type=req.getParameter("u_type");
		String u_otp=req.getParameter("u_otp_def");
		String my_otp=req.getParameter("u_otp_user");
		User u=new User();
		u.setEmail(email);
		u.setContact_Number(c_Phone);		
		u.setName(name);
		u.setPassword(c_pass);		
		u.setUtype(u_type);
		if(u_otp.equals(my_otp)) {
			User_Duo ud=new User_Duo();
			u.setEmail(email);
			u.setUtype("Patient");
			u.setContact_Number(c_Phone);
			u.setName(name);			
			u.setPassword(c_pass);					
			ud.User_Register(u);
			ModelAndView mv=new ModelAndView();
			mv.setViewName("Login");
	        return mv;  
		}
		else {
			ModelAndView mv=new ModelAndView();
			mv.setViewName("OTP");
			mv.addObject("user",u);
	        return mv;  
			
		}
	}
	
	@RequestMapping("/UserDash")
	public String user_dash() 
	{
		 return "UserDash";  
	}
	
	@RequestMapping("/Login")
	public String Log(HttpSession session) 
	{
		try {
			if(session.getAttribute("type").equals("Staff")) {
				return "Hos_Dash";			
			}
			if(session.getAttribute("type").equals("Patient")) {
				return "forward:/Sh_Hos";
			}
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		
		return "Login";  
	}
	
	@RequestMapping(value = "/log",method = RequestMethod.POST)
	public ModelAndView Login(HttpServletRequest req,Model m,HttpSession session,HttpServletResponse  response) throws IOException {
		
		 String u_emial=req.getParameter("u_emial");
		 String u_pass=req.getParameter("u_pass");
		 
		 com.duo.User_Duo ud=new User_Duo();
		 int status=ud.login(u_emial,u_pass);
		 ModelAndView mv=new ModelAndView();
		 if(status!=0) {
			 User u=ud.user_type(u_emial);
			 String type=u.getUtype();
			 String name=u.getName();
			 session.setAttribute("email", u_emial);
			 session.setAttribute("id", status);
			 session.setAttribute("type", type);
			 session.setAttribute("username",name);
			 	if(session.getAttribute("type").equals("Staff")) {
			 		
			 		mv.setViewName("Hos_Dash");			 		
				}
				if(session.getAttribute("type").equals("Patient")) {
					mv.addObject("Error","User Not");
					response.sendRedirect("Sh_Hos");  
					 mv.setViewName("forward:/Sh_Hos");
					
				}
			 
			
			 return mv;
		 }
		 mv.addObject("Error","Your Email or Password is Not Register");
		 mv.setViewName("Login");		 
		 return mv;
		 
	}
	@RequestMapping(value = "/hos_reg",method = RequestMethod.GET)
	public String hos_reg() {
		 	return "HospitalRegister";
		 }
	
	@RequestMapping(value = "/logout",method = RequestMethod.GET)
	public String log_out(HttpSession session,HttpServletRequest req) {
		 session=req.getSession();  
         session.invalidate(); 
		return "index";
	}
	@RequestMapping("Update_Profile")
	public ModelAndView update_profile(HttpSession session,HttpServletRequest request) {
	try {
		ModelAndView mv=new ModelAndView();
		int id=Integer.parseInt(session.getAttribute("id").toString());
		System.out.println(id);
		User user=new User();
		User_Duo uc=new User_Duo();
		user=uc.update(id);
		System.out.println(user.getContact_Number());
		mv.setViewName("Update_Details");
		mv.addObject("user",user);
		return mv;
	}
	catch (Exception e) {
		// TODO: handle exception
		System.out.println(e);
		ModelAndView mv=new ModelAndView();
		mv.setViewName("Login");
		return mv;
	}
		
	}
	@RequestMapping(value = "Update_User_Profile",method = RequestMethod.POST)
	public void up_profile(HttpServletRequest req,HttpSession session,PrintWriter out) {
		String name=req.getParameter("u_name");    
		String email=req.getParameter("u_emial");		
		String c_ph=req.getParameter("u_no");		
		String pass=req.getParameter("u_pass");
		
		User u=new User();
		u.setContact_Number(c_ph);
		u.setEmail(email);
		u.setId(Integer.parseInt(session.getAttribute("id").toString()));
		u.setName(name);
		u.setPassword(pass);
		String type=session.getAttribute("type").toString();
		u.setUtype(type);
		User_Duo duo=new User_Duo();
		boolean update=duo.update(u);
		if(update) {
			  out.println("<script type=\"text/javascript\">");
			  out.println("alert('Your Profile  is Updated');");
			  out.println("window.location = 'http://localhost:8080/H_Hub/Login';\r\n" + "");
			  out.println("</script>");
		}
		else {
			out.println("<script type=\"text/javascript\">");
			  out.println("alert('Your Profile  is Not Updated');");
			  out.println("window.location = 'http://localhost:8080/H_Hub/Login';\r\n" + "");
			  out.println("</script>");
			
		}
	}

	
    
}  