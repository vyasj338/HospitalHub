package com.process;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.hibernate.HibernateException;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

import com.model.Doctor;
import com.model.Hospital;

/**
 * Servlet implementation class Sh_Hos
 */
public class Sh_Hos extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.getRequestDispatcher("/WEB-INF/jsp/Header.jsp").include(request, response);
		PrintWriter out = response.getWriter();
		out.print("<br/><br/>");
		out.print("<div class=\"container\">");
		out.print("\r\n"
				+ "<div class=\"row\">\r\n"
				+ "<br>"
				+ "  <div class=\"col-4\">\r\n"
				+ "  <ul class=\"list-group\">\r\n"
				+ "      <div class=\"list-group\" id=\"list-tab\" role=\"tablist\">\r\n"
				+ "      <a class=\"list-group-item list-group-item-action active\" id=\"list-home-list\"  href=\"Login\" role=\"tab\" aria-controls=\"home\">Book Appoiment</a>\r\n"
				+ "      <a class=\"list-group-item list-group-item-action\" id=\"list-profile-list\"  href=\"ShowAppoimentStatus\" role=\"tab\" aria-controls=\"profile\">Show Booked Appoiment Status</a>\r\n"
				+ "      <a class=\"list-group-item list-group-item-action\" id=\"list-messages-list\" href=\"Rate_Appoiment\" role=\"tab\" aria-controls=\"messages\">Give Rate Your Appoiment</a>\r\n"				
				+ "      <a class=\"list-group-item list-group-item-action\" id=\"list-settings-list\"  href=\"Update_Profile\" role=\"tab\" aria-controls=\"settings\">Update Your Details</a>\r\n"				
				+ "    </div>\r\n"
				+ "</ul>\r\n"
				+ "  </div>\r\n"
				+ "  <div class=\"col-8 container\">\r\n"
				+ "  	<center><h3>Welcome TO  HOSPITAL HUB</h3></center>\r\n"				
				+ "");
		Configuration con=new Configuration().configure().addAnnotatedClass(Doctor.class).addAnnotatedClass(Hospital.class);
		ServiceRegistry reg = (ServiceRegistry) new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
		SessionFactory sf=con.buildSessionFactory((org.hibernate.service.ServiceRegistry) reg);
		Session session = sf.openSession();	      
		Transaction tx=null;
	      try {
	    	  tx=session.beginTransaction();
	         String sql = "SELECT * FROM tbl_hospital";	         
	         SQLQuery query = session.createSQLQuery(sql);	         
	         query.addEntity(Hospital.class);
	         List hospitals = query.list();
	         out.print("<div class=\"row row-cols-1 row-cols-md-3\">\r\n");
	         for (Iterator iterator = hospitals.iterator(); iterator.hasNext();){
	             Hospital hospital = (Hospital) iterator.next();	             
	             out.print("  <div class=\"col mb-4\">\r\n"
	             		+ "");
	             out.print("<div class=\"card\" style=\"width: 18rem;\">\r\n"
	             		+ "  <div class=\"card-body\">\r\n"
	             		+ "    <h5 class=\"card-title\">"+hospital.getName()+"</h5>\r\n"
	             		+ "    <h6 class=\"card-subtitle mb-2 text-muted\">"+hospital.getTelephone()+"</h6>\r\n"
	             		+ "    <p class=\"card-text\">"+hospital.getAddress()+"</p>\r\n"
	             	    + "    <a href=\"show_dr_for_appoiment?id="+hospital.getId()+"\""+hospital.getId()+">Book Appointment</a>\r\n"
	             			             		
	             		+ "  </div>\r\n"
	             		+ "</div>");
	              out.print("</div>");
	          }
	         out.print("</div>");

	         tx.commit();
	      } catch (HibernateException e) {
	         if (tx!=null) tx.rollback();
	         e.printStackTrace(); 
	      } finally {
	         session.close(); 
	      }
		
	}

}
