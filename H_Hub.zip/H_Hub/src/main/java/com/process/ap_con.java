package com.process;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

import com.model.Appoiment;
import com.model.Book_Appoiment;
import com.model.Doctor;
import com.model.Hospital;
import com.model.User;

/**
 * Servlet implementation class ap_con
 */
public class ap_con extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("/WEB-INF/jsp/Header.jsp").include(request, response);
		Configuration con=new Configuration().configure().addAnnotatedClass(Appoiment.class).addAnnotatedClass(Doctor.class).addAnnotatedClass(Hospital.class).addAnnotatedClass(Book_Appoiment.class).addAnnotatedClass(User.class);
		ServiceRegistry reg = (ServiceRegistry) new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
		SessionFactory sf=con.buildSessionFactory((org.hibernate.service.ServiceRegistry) reg);		
		Session session = sf.openSession();	      
		Transaction tx=null;

		try {
			tx = session.beginTransaction();
		     String sql = "SELECT * FROM tbl_appoiment_manager WHERE am_St = :Status ";	         
	         SQLQuery query = session.createSQLQuery(sql);	         
	         query.addEntity(Book_Appoiment.class);	         	         
	         query.setParameter("Status", "Complete");
	         List<Book_Appoiment> appoiments = query.list();// Add restriction.
	         
	         
	         
	         	         
	        
	         PrintWriter out = response.getWriter();
	         out.print("<div class='container'>");
	         out.print("<table class=\"table table-striped \">\r\n"
	         		+ "  <thead>\r\n"
	         		+ "    <tr>\r\n"	         		
	         		+ "      <th scope=\"col\">Hospital Name</th>\r\n"
	         		+ "      <th scope=\"col\">Doctor Name</th>\r\n"
	         		+ "      <th scope=\"col\">Date</th>\r\n"
	         		+ "      <th scope=\"col\">Time</th>\r\n"
	         		+ "      <th scope=\"col\">Rate</th>\r\n"	         		
	         		+ "    </tr>\r\n"
	         		+ "  </thead>");
	         for(Book_Appoiment appoiment : appoiments) {
	        	 String rate=null;
	        	 if(appoiment.getRate()==0) {
	        		  rate="Not Given By User";
	        	 }
	        	 else {
	        		  rate=String.valueOf(appoiment.getRate());
	        	 }
	        	 out.print("<tbody>\r\n"
	        	 		+ "    <tr>\r\n"
	        	 		+ "      <td>"+appoiment.getA().getD().getH().getName()+"</td>\r\n"
	        	 		+ "      <td>"+appoiment.getA().getD().getName()+"</td>\r\n"
	        	 		+ "      <td>"+appoiment.getA().getDt()+"</td>\r\n"
	        	 		+ "      <td>"+appoiment.getA().getTime()+"</td>\r\n"
	        	 		+ "      <td>"+rate+"</td>\r\n"
	        	 				+ "</a></td>\r\n"	        	 			        	 		
	        	 		+ "    </tr>\r\n");	       
	         }	         
	         tx.commit();
	         out.print("</div>");
	   
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		} 

	}


}
