package com.process;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

import com.model.Appoiment;
import com.model.Doctor;
import com.model.Hospital;

/**
 * Servlet implementation class Ap_list
 */
public class Ap_list extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("/WEB-INF/jsp/Header.jsp").include(request, response);
		Configuration con=new Configuration().configure().addAnnotatedClass(Appoiment.class).addAnnotatedClass(Doctor.class).addAnnotatedClass(Hospital.class);
		ServiceRegistry reg = (ServiceRegistry) new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
		SessionFactory sf=con.buildSessionFactory((org.hibernate.service.ServiceRegistry) reg);
		Session session = sf.openSession();	      
		Transaction tx=null;

		try {
			tx = session.beginTransaction();
	         Criteria cr = session.createCriteria(Appoiment.class);
	         // Add restriction.
	         
	         int id=Integer.parseInt(request.getParameter("id"));
	         cr.add(Restrictions.eq("d.id", id));
	         List<Appoiment> appoiments = cr.list();	         
	        
	         PrintWriter out = response.getWriter();
	         out.print("<div class='container'>");
	         out.print("<table class=\"table table-striped \">\r\n"
	         		+ "  <thead>\r\n"
	         		+ "    <tr>\r\n"	         		
	         		+ "      <th scope=\"col\">Date</th>\r\n"
	         		+ "      <th scope=\"col\">Time</th>\r\n"
	         		+ "      <th scope=\"col\">Show Pending Appointment List</th>\r\n"
	         		+ "      <th scope=\"col\">Show Accepted Appointment List</th>\r\n"
	         		+ "      <th scope=\"col\">Show Rejected Appointment List</th>\r\n"
	         		+ "      <th scope=\"col\">Show Rate Of Appointment List</th>\r\n"
	         		+ "    </tr>\r\n"
	         		+ "  </thead>");
	         for(Appoiment appoiment : appoiments) {
	        	 out.print("<tbody>\r\n"
	        	 		+ "    <tr>\r\n"
	        	 		+ "      <td>"+appoiment.getDt()+"</td>\r\n"
	        	 		+ "      <td>"+appoiment.getTime()+"</td>\r\n"
	    	        	+ "      <td><a href='ap_pen?id="+appoiment.getId()+"&st=Pending'><center>Show</center></a></td>\r\n"
	    	        	+ "      <td><a href='ap_ac?id="+appoiment.getId()+"&st=Accepted'><center>Show</center></td>\r\n"
	    	        	+ "      <td><a href='ap_can?id="+appoiment.getId()+"&st=Cancel'><center>Show</center></td>\r\n"
	    	        	+ "      <td><a href='ap_rate_by_user?id="+appoiment.getId()+"&st=Cancel'><center>Show</center></td>\r\n"
	        	 		+ "    </tr>\r\n"
	        	 		+ "  ");
	       
	         }
	         
	         tx.commit();
	         out.print("</div>");
	   
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		} 
	}

	
}
