package com.process;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

import com.duo.Hospital_Duo;
import com.model.Doctor;
import com.model.Hospital;

/**
 * Servlet implementation class Show_Doctor_Appoiment
 */
public class Show_Doctor_Appoiment extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.getRequestDispatcher("/WEB-INF/jsp/Header.jsp").include(request, response);

		Configuration con=new Configuration().configure().addAnnotatedClass(Hospital.class).addAnnotatedClass(Doctor.class);
		ServiceRegistry reg = (ServiceRegistry) new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
		SessionFactory sf=con.buildSessionFactory((org.hibernate.service.ServiceRegistry) reg);
		Session session = sf.openSession();	      
		Transaction tx=null;
          

	      try {
	         tx = session.beginTransaction();
	         Criteria cr = session.createCriteria(Doctor.class);
	         // Add restriction.
	         Hospital_Duo hd=new Hospital_Duo();	         
	         int id=Integer.parseInt(request.getParameter("id"));
	         cr.add(Restrictions.eq("hospital.id", id));
	         List<Doctor> doctors = cr.list();	         
	        
	         PrintWriter out = response.getWriter();
	         out.print("<div class='container'>");
	         out.print("<table class=\"table table-striped \">\r\n"
	         		+ "  <thead>\r\n"
	         		+ "    <tr>\r\n"	         		
	         		+ "      <th scope=\"col\">Name</th>\r\n"
	         		+ "      <th scope=\"col\">Specialization</th>\r\n"
	         		+ "      <th scope=\"col\">Click Here To Set Appointment</th>\r\n"
	         		+ "      <th scope=\"col\">Show All Add Appoiment</th>\r\n"
	         		+ "    </tr>\r\n"
	         		+ "  </thead>");
	         for(Doctor doctor : doctors) {
	        	 out.print("<tbody>\r\n"
	        	 		+ "    <tr>\r\n"
	        	 		+ "      <td>"+doctor.getName()+"</td>\r\n"
	        	 		+ "      <td>"+doctor.getSpecialization()+"</td>\r\n"
	        	 		+ "      <td><a href='add_ap?id="+doctor.getId()+"'>Add Appointment</a></td>\r\n"	        	 		
	        	 		+ "      <td><a href='sh_ap?id="+doctor.getId()+"'>Show</a></td>\r\n"
	        	 		+ "    </tr>\r\n"
	        	 		+ "  ");
	       
	         }
	         
	         tx.commit();
	         out.print("</div>");
	           
	      } catch (HibernateException e) {
	         if (tx!=null) tx.rollback();
	         e.printStackTrace(); 
	      } finally {
	         session.close(); 
	      }
	      PrintWriter out = response.getWriter();
	      
	}

}

