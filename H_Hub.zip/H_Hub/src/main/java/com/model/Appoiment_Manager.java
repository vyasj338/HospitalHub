package com.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_appoiment_manager")
public class Appoiment_Manager {
	
	@Id
	@GeneratedValue
	@Column(name = "am_id")
	int id;
	@Column(name="am_St")
	String Status;
	@Column(name="pt_name")
	String name;
	@Column(name="pt_Cn")
	String cn;

	@Column(name="am_rate")
	int rate;
	@Column(name="am_pyment_status")
	String ps;
	
	@OneToOne
	@JoinColumn(name = "a_id")
	Appoiment a;
	
	@ManyToOne
	@JoinColumn(name = "u_id")
	User u;
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCn() {
		return cn;
	}

	public void setCn(String cn) {
		this.cn = cn;
	}

	public String getPs() {
		return ps;
	}

	public void setPs(String ps) {
		this.ps = ps;
	}
	
	public String getStatus() {
		return Status;
	}
	
	public void setStatus(String status) {
		Status = status;
	}
	
	public int getRate() {
		return rate;
	}
	
	public void setRate(int rate) {
		this.rate = rate;
	}
	
	public Appoiment getA() {
		return a;
	}
	
	public void setA(Appoiment a) {
		this.a = a;
	}

	public User getU() {
		return u;
	}

	public void setU(User u) {
		this.u = u;
	}
		
}
