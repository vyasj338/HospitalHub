package com.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_Card")
public class Card {
	@Id
	@GeneratedValue
	@Column(name = "c_id")
	private int id;
	@OneToOne
	@JoinColumn(name = "a_id")
	Appoiment_Manager am;
	@Column(name="cr_name")
	private String name;
	@Column(name="cr_exp")
	private String exp;
	@Column(name="cr_cvv")
	private String cvv;
	@Column(name="cr_no")
	private String cr_no;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Appoiment_Manager getAm() {
		return am;
	}
	public void setAm(Appoiment_Manager am) {
		this.am = am;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getExp() {
		return exp;
	}
	public void setExp(String exp) {
		this.exp = exp;
	}
	public String getCvv() {
		return cvv;
	}
	public void setCvv(String cvv) {
		this.cvv = cvv;
	}
	public String getCr_no() {
		return cr_no;
	}
	public void setCr_no(String cr_no) {
		this.cr_no = cr_no;
	}
	
	

}
