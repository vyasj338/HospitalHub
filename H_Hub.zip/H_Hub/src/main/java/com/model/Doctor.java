package com.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_Doctor")
public class Doctor {
	@Id
	@GeneratedValue
	@Column(name = "d_id")
	private int id;
	@OneToOne
	@JoinColumn(name = "h_id")
	Hospital hospital;
	@Column(name="d_name")
	private String name;
	@Column(name="d_Specialization")
	private String Specialization;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Hospital getH() {
		return hospital;
	}
	public void setH(Hospital hospital) {
		this.hospital = hospital;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSpecialization() {
		return Specialization;
	}
	public void setSpecialization(String specialization) {
		Specialization = specialization;
	}
	
	

}
