package com.model;

import java.awt.Paint;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import antlr.collections.List;

@Entity
@Table(name = "tbl_appoiment")
public class Appoiment {
	@Id
	@GeneratedValue
	@Column(name = "a_id")
	int id;
	@OneToOne
	@JoinColumn(name = "d_id")
	Doctor d;
	@Column(name = "a_date")
	String dt;
	@Column(name = "a_time")
	String time;
	
	
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Doctor getD() {
		return d;
	}
	public void setD(Doctor d) {
		this.d = d;
	}
	public String getDt() {
		return dt;
	}
	public void setDt(String dt) {
		this.dt = dt;
	}
	
}
