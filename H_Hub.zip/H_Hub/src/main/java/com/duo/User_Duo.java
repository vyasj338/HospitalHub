package com.duo;

import java.util.Random;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

import com.model.Hospital;
import com.model.Patient;
import com.model.Staff;
import com.model.User;



public class User_Duo {
	public boolean User_Register(User u) {
		try {
			Patient p = new Patient();
			p.setUser(u);
			Configuration con=new Configuration().configure().addAnnotatedClass(User.class).addAnnotatedClass(Patient.class);
			ServiceRegistry reg = (ServiceRegistry) new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
			SessionFactory sf=con.buildSessionFactory((org.hibernate.service.ServiceRegistry) reg);
			Session session = sf.openSession();
			Transaction tx=session.beginTransaction();		
			session.save(p);
			session.save(u);			
			tx.commit();
			return true;
		}catch (Exception e) {
			return false;
		}
		
	}
	public boolean User_Register_Hos_Staff(User u,Staff s) {
		try {			
			Configuration con=new Configuration().configure().addAnnotatedClass(User.class).addAnnotatedClass(Hospital.class).addAnnotatedClass(Staff.class);
			ServiceRegistry reg = (ServiceRegistry) new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
			SessionFactory sf=con.buildSessionFactory((org.hibernate.service.ServiceRegistry) reg);
			Session session = sf.openSession();
			Transaction tx=session.beginTransaction();		
			session.save(u);			
			session.save(s);
			tx.commit();
			return true;
		}catch (Exception e) {
			System.out.print(e);
			return false;
		}

	}
	
	public boolean User_Register_Staff(User u,Hospital h) {
		try {
			Staff s=new Staff();
			s.setHospital(h);
			s.setUser(u);
			Configuration con=new Configuration().configure().addAnnotatedClass(User.class).addAnnotatedClass(Hospital.class).addAnnotatedClass(Staff.class);
			ServiceRegistry reg = (ServiceRegistry) new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
			SessionFactory sf=con.buildSessionFactory((org.hibernate.service.ServiceRegistry) reg);
			Session session = sf.openSession();
			Transaction tx=session.beginTransaction();
			session.save(h);
			session.save(u);			
			session.save(s);			
			tx.commit();
			return true;
		}catch (Exception e) {
			System.out.print(e);
			return false;
		}

	}
	
	
	public String otp_genrate() 
	{
  
		// create a string of all characters
	    String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";

	    // create random string builder
	    StringBuilder sb = new StringBuilder();

	    // create an object of Random class
	    Random random = new Random();

	    // specify length of random string
	    int length = 7;

	    for(int i = 0; i < length; i++) {

	      // generate random index number
	      int index = random.nextInt(alphabet.length());

	      // get character specified by index
	      // from the string
	      char randomChar = alphabet.charAt(index);

	      // append the character to string builder
	      sb.append(randomChar);
	    }

	    String randomString = sb.toString();
	    return randomString;

	}
	public Boolean check_otp(String otp,User u) {
		 if(otp.equals(u.getOtp())) {
			 return true;
		 }
		 else {
			 return false;
		 }
		
	}
	
	public Boolean check_user_status(String uemail) {
		 Transaction transaction = null;
	        User user = null;
	        Configuration con=new Configuration().configure().addAnnotatedClass(User.class).addAnnotatedClass(Patient.class);
			ServiceRegistry reg = (ServiceRegistry) new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
	        SessionFactory sf=con.buildSessionFactory((org.hibernate.service.ServiceRegistry) reg);
	        Session session = sf.openSession();
	        try  {
	            // start a transaction
	            transaction = session.beginTransaction();
	            // get an user object
	            user = (User) session.createQuery("FROM User U WHERE U.Email = :userEmail").setParameter("userEmail", uemail)
	                .uniqueResult();

	            if (user != null) {
	                return true;
	            }
	            // commit transaction
	            transaction.commit();
	        } catch (Exception e) {
	            if (transaction != null) {
	                transaction.rollback();
	            }
	            e.printStackTrace();
	        }
	        return false;
	}
	
	public int login(String uemail,String uPass) {

        Transaction transaction = null;
        User user = null;
        Configuration con=new Configuration().configure().addAnnotatedClass(User.class).addAnnotatedClass(Patient.class);
		ServiceRegistry reg = (ServiceRegistry) new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
        SessionFactory sf=con.buildSessionFactory((org.hibernate.service.ServiceRegistry) reg);
        Session session = sf.openSession();
        try  {
            // start a transaction
            transaction = session.beginTransaction();
            // get an user object
            user = (User) session.createQuery("FROM User U WHERE U.Email = :userEmail").setParameter("userEmail", uemail)
                .uniqueResult();

            if (user != null && user.getPassword().equals(uPass)) {
                return user.getId();
            }
            // commit transaction
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
        return 0;
    }
	public User user_type(String uemail) {

        Transaction transaction = null;
        User user = null;
        Configuration con=new Configuration().configure().addAnnotatedClass(User.class).addAnnotatedClass(Patient.class);
		ServiceRegistry reg = (ServiceRegistry) new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
        SessionFactory sf=con.buildSessionFactory((org.hibernate.service.ServiceRegistry) reg);
        Session session = sf.openSession();
        try  {
            // start a transaction
            transaction = session.beginTransaction();
            // get an user object
            user = (User) session.createQuery("FROM User U WHERE U.Email = :userEmail").setParameter("userEmail", uemail)
                .uniqueResult();

            if (user != null ) {
                return user;
            }
            // commit transaction
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
        return user;

	}
	public User update(int id) {
		try {
			
			Configuration con=new Configuration().configure().addAnnotatedClass(User.class).addAnnotatedClass(Hospital.class).addAnnotatedClass(Staff.class);
			ServiceRegistry reg = (ServiceRegistry) new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
			SessionFactory sf=con.buildSessionFactory((org.hibernate.service.ServiceRegistry) reg);
			Session session = sf.openSession();
			Transaction tx=session.beginTransaction();
			User user = (User) session.get(User.class, id);
						
			tx.commit();
			return user;
		}catch (Exception e) {
			System.out.print(e);
			User user=new User();
			
			return user;
		}
	}
	public boolean update(User user) {
		try {
			Configuration con=new Configuration().configure().addAnnotatedClass(User.class).addAnnotatedClass(Hospital.class).addAnnotatedClass(Staff.class);
			ServiceRegistry reg = (ServiceRegistry) new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
			SessionFactory sf=con.buildSessionFactory((org.hibernate.service.ServiceRegistry) reg);
			Session session = sf.openSession();
			Transaction tx=session.beginTransaction();
			session.update(user);						
			tx.commit();
			return true;
		} catch (Exception e) {
			return false;
		}
		
	}
	
	
}