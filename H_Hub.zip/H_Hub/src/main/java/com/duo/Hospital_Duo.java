package com.duo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

import com.model.Appoiment;
import com.model.Appoiment_Manager;
import com.model.Card;
import com.model.Doctor;
import com.model.Hospital;
import com.model.Staff;
import com.model.User;
import com.mysql.cj.Query;



public class Hospital_Duo {
	public int find_h_id(int id) {
        Transaction transaction = null;
        
        Configuration con=new Configuration().configure().addAnnotatedClass(Staff.class).addAnnotatedClass(Hospital.class).addAnnotatedClass(User.class);
		ServiceRegistry reg = (ServiceRegistry) new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
        SessionFactory sf=con.buildSessionFactory((org.hibernate.service.ServiceRegistry) reg);
        Session session = sf.openSession();
        Staff s=null;
        try  {
            // start a transaction
            transaction = session.beginTransaction();
            // get an user object
             s = (Staff) session.createQuery("FROM Staff s WHERE s.user.id = :id").setParameter("id", id)
                .uniqueResult();
            
            
            // commit transaction
            transaction.commit();            
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
                System.out.println();
            }
            e.printStackTrace();
        }
        return s.getHospital().getId();

	}
	public boolean add_dr(Doctor d) {
		try {			
			Configuration con=new Configuration().configure().addAnnotatedClass(Hospital.class).addAnnotatedClass(Doctor.class);
			ServiceRegistry reg = (ServiceRegistry) new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
			SessionFactory sf=con.buildSessionFactory((org.hibernate.service.ServiceRegistry) reg);
			Session session = sf.openSession();
			Transaction tx=session.beginTransaction();		
			session.save(d);
			tx.commit();
			return true;
		}catch (Exception e) {
			System.out.print(e);
			return false;
		}

	}
	public boolean del_dr(Doctor d) {
		try {			
			Configuration con=new Configuration().configure().addAnnotatedClass(Hospital.class).addAnnotatedClass(Doctor.class);
			ServiceRegistry reg = (ServiceRegistry) new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
			SessionFactory sf=con.buildSessionFactory((org.hibernate.service.ServiceRegistry) reg);
			Session session = sf.openSession();
			Transaction tx=session.beginTransaction();		
			session.delete(d);
			System.out.println("Delete Sucess Full");
			tx.commit();
			return true;
		}catch (Exception e) {
			System.out.print(e);
			return false;
		}
	}
	public Doctor fetch_record_fr(int id) {
		
		Configuration con=new Configuration().configure().addAnnotatedClass(Doctor.class).addAnnotatedClass(Hospital.class);
		
		ServiceRegistry reg = (ServiceRegistry) new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
		
		SessionFactory sf=con.buildSessionFactory((org.hibernate.service.ServiceRegistry) reg);
		
		Session session = sf.openSession();
		
		try {
			Doctor doctor=(Doctor) session.get(Doctor.class,id);
			return doctor;
			
		} catch (Exception e) {
			Doctor doctor=new Doctor();
			return doctor;
		}
		
	}	
	public Boolean update_dr(Doctor dr) {
		Configuration con=new Configuration().configure().addAnnotatedClass(Doctor.class).addAnnotatedClass(Hospital.class);
		
		ServiceRegistry reg = (ServiceRegistry) new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
		
		SessionFactory sf=con.buildSessionFactory((org.hibernate.service.ServiceRegistry) reg);
		
		Session session = sf.openSession();
		Transaction tx=session.beginTransaction();
		try {
			session.update(dr);
			tx.commit();
			return true;
			
		} catch (Exception e) {
			
			return false;
		}

	}
	public Boolean add_appoiment(Appoiment ap) {
		Configuration con=new Configuration().configure().addAnnotatedClass(Doctor.class).addAnnotatedClass(Hospital.class).addAnnotatedClass(Appoiment.class);
		
		ServiceRegistry reg = (ServiceRegistry) new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
		
		SessionFactory sf=con.buildSessionFactory((org.hibernate.service.ServiceRegistry) reg);
		
		Session session = sf.openSession();
		Transaction tx=session.beginTransaction();
		try {
			session.save(ap);
			tx.commit();
			return true;
		}
		 catch (Exception e) {	
			 return false;
		 }
	}
	public void update_appoiment(Appoiment ap) {
		Configuration con=new Configuration().configure().addAnnotatedClass(Doctor.class).addAnnotatedClass(Hospital.class).addAnnotatedClass(Appoiment.class);
		
		ServiceRegistry reg = (ServiceRegistry) new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
		
		SessionFactory sf=con.buildSessionFactory((org.hibernate.service.ServiceRegistry) reg);
		
		Session session = sf.openSession();
		Transaction tx=session.beginTransaction();
		try {
			session.update(ap);
			tx.commit();
			
		}
		 catch (Exception e) {	
			System.out.println(e);
		 }
	}
	public void del_appoiment(Appoiment ap) {
		Configuration con=new Configuration().configure().addAnnotatedClass(Doctor.class).addAnnotatedClass(Hospital.class).addAnnotatedClass(Appoiment.class);
		
		ServiceRegistry reg = (ServiceRegistry) new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
		
		SessionFactory sf=con.buildSessionFactory((org.hibernate.service.ServiceRegistry) reg);
		
		Session session = sf.openSession();
		Transaction tx=session.beginTransaction();
		try {
			session.delete(ap);
			tx.commit();
			
		}
		 catch (Exception e) {	
			System.out.println(e);
		 }
	}
	public Hospital show_rec(int h) {
		Configuration con=new Configuration().configure().addAnnotatedClass(Doctor.class).addAnnotatedClass(Hospital.class).addAnnotatedClass(Appoiment.class);
		
		ServiceRegistry reg = (ServiceRegistry) new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
		
		SessionFactory sf=con.buildSessionFactory((org.hibernate.service.ServiceRegistry) reg);
		
		Session session = sf.openSession();
		Transaction tx=session.beginTransaction();
		
		try {
			Hospital hospital=(Hospital) session.get(Hospital.class,h);
			tx.commit();
			System.out.println(hospital.getAddress());
			return hospital;
			
		}
		 catch (Exception e) {	
			 Hospital hospital=new Hospital();
			System.out.println(e);
			return hospital;
			
		 }
	
	}
	public boolean up_ho(Hospital h) {
		Configuration con=new Configuration().configure().addAnnotatedClass(Doctor.class).addAnnotatedClass(Hospital.class).addAnnotatedClass(Appoiment.class);
		
		ServiceRegistry reg = (ServiceRegistry) new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
		
		SessionFactory sf=con.buildSessionFactory((org.hibernate.service.ServiceRegistry) reg);
		
		Session session = sf.openSession();
		Transaction tx=session.beginTransaction();
		
		try {
			session.update(h);
			tx.commit();
			
			return true;
			
		}
		 catch (Exception e) {				 
			System.out.println(e);
			return false;
			
		 }
	
	}
	public void book_appoiment(Appoiment_Manager am,Card c) {
		Configuration con=new Configuration().configure().addAnnotatedClass(Doctor.class).addAnnotatedClass(Hospital.class).addAnnotatedClass(Appoiment.class).addAnnotatedClass(Appoiment_Manager.class).addAnnotatedClass(User.class).addAnnotatedClass(Card.class).addAnnotatedClass(Appoiment.class);
		
		ServiceRegistry reg = (ServiceRegistry) new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
		
		SessionFactory sf=con.buildSessionFactory((org.hibernate.service.ServiceRegistry) reg);
		
		Session session = sf.openSession();
		Transaction tx=session.beginTransaction();
		
		try {
			session.save(am);
			session.save(c);
			tx.commit();
			
			
			
		}
		 catch (Exception e) {				 
			System.out.println(e);
			
			
		 }
	}
	public void appoimentbook_update(Appoiment_Manager am) {
Configuration con=new Configuration().configure().addAnnotatedClass(Doctor.class).addAnnotatedClass(Hospital.class).addAnnotatedClass(Appoiment.class).addAnnotatedClass(Appoiment_Manager.class).addAnnotatedClass(User.class).addAnnotatedClass(Card.class).addAnnotatedClass(Appoiment.class);
		
		ServiceRegistry reg = (ServiceRegistry) new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
		SessionFactory sf=con.buildSessionFactory((org.hibernate.service.ServiceRegistry) reg);
		
		Session session = sf.openSession();
		Transaction tx=session.beginTransaction();
		int id=am.getId();
		try {
			Appoiment_Manager am_new = (Appoiment_Manager) session.get(Appoiment_Manager.class, id);
			am_new.setStatus(am.getStatus());;
			am_new.setRate(am.getRate());
			session.saveOrUpdate(am_new);

			tx.commit();
			
			
			
		}
		 catch (Exception e) {				 
			System.out.println(e);
			
			
		 }
	}
	
	


}
