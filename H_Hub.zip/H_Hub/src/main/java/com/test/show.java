package com.test;

import java.util.*; 

import org.hibernate.HibernateException; 
import org.hibernate.Session; 
import org.hibernate.Transaction;
import org.hibernate.SessionFactory;
import org.hibernate.SQLQuery;
import org.hibernate.Criteria;
import org.hibernate.Hibernate;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

import com.model.Doctor;
import com.model.Hospital;
import com.model.Staff;
import com.model.User;




public class show {
	public static void main(String[] args) {
		Configuration con=new Configuration().configure().addAnnotatedClass(Doctor.class).addAnnotatedClass(Hospital.class);
		ServiceRegistry reg = (ServiceRegistry) new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
		SessionFactory sf=con.buildSessionFactory((org.hibernate.service.ServiceRegistry) reg);
		Session session = sf.openSession();	      
		Transaction tx=null;
	      try {
	    	  tx=session.beginTransaction();
	         String sql = "SELECT d_name  FROM tbl_doctor WHERE h_id= :h_id";	         
	         SQLQuery query = session.createSQLQuery(sql);
	         query.setParameter("h_id", 1);
	         query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
	         List data = query.list();

	         for(Object object : data) {
	            Map row = (Map)object;
	            System.out.print("First Name: " + row.get("d_name")); 
	             
	         }
	         tx.commit();
	      } catch (HibernateException e) {
	         if (tx!=null) tx.rollback();
	         e.printStackTrace(); 
	      } finally {
	         session.close(); 
	      }
	}

}
