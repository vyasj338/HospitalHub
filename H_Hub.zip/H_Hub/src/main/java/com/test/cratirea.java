package com.test;

import java.util.Iterator;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

import com.model.Doctor;
import com.model.Hospital;



import java.util.List; 

 
import org.hibernate.HibernateException; 



public class cratirea {

	public static void main(String[] args) {
		Configuration con=new Configuration().configure().addAnnotatedClass(Hospital.class).addAnnotatedClass(Doctor.class);
		ServiceRegistry reg = (ServiceRegistry) new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
		SessionFactory sf=con.buildSessionFactory((org.hibernate.service.ServiceRegistry) reg);
		Session session = sf.openSession();	      
		Transaction tx=null;
		
	      try {
	         tx = session.beginTransaction();
	         Criteria cr = session.createCriteria(Doctor.class);
	         // Add restriction.
	         cr.add(Restrictions.eq("hospital.id", 1));
	         List doctors = cr.list();
	         
	         for (Iterator<Doctor> iterator = doctors.iterator(); iterator.hasNext();){
	            Doctor doctor = (Doctor) iterator.next(); 	            
	            System.out.println("First Name: " + doctor.getName()); 
	            //System.out.print("  Last Name: " +doctor.getSpecialization()); 
	             
	         }
	         tx.commit();
	      } catch (HibernateException e) {
	         if (tx!=null) tx.rollback();
	         e.printStackTrace(); 
	      } finally {
	         session.close(); 
	      }
	      
	}

}
